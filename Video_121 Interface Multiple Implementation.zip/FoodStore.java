package com.selenium4beginners.java.oop.abstraction.interfaces;

public interface FoodStore extends EmailServiceProvider {

	public void sellFruits ();
	public void sellVegetables ();	
}